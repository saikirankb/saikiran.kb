import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AdminPanel = () => {
  const [jobs, setJobs] = useState([]);
  const [form, setForm] = useState({ title: '', description: '', location: '', salary: '', email: '' });

  useEffect(() => {
    axios.get('http://localhost:5000/admin/jobs').then((response) => setJobs(response.data));
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/admin/job', form).then(() => window.location.reload());
  };

  return (
    <div>
      <h1>Admin Panel</h1>
      <form onSubmit={handleSubmit}>
        <input placeholder="Job Title" onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input placeholder="Description" onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <input placeholder="Location" onChange={(e) => setForm({ ...form, location: e.target.value })} />
        <input placeholder="Salary" onChange={(e) => setForm({ ...form, salary: e.target.value })} />
        <input placeholder="Contact Email" onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <button type="submit">Add Job</button>
      </form>

      <h2>Existing Jobs</h2>
      <table>
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Location</th>
            <th>Salary</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {jobs.map((job) => (
            <tr key={job.id}>
              <td>{job.title}</td>
              <td>{job.description}</td>
              <td>{job.location}</td>
              <td>{job.salary}</td>
              <td>{job.email}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminPanel;
