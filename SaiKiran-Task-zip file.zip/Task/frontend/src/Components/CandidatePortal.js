import React, { useState, useEffect } from 'react';

import axios from 'axios';

const CandidatePortal = () => {
  const [jobs, setJobs] = useState([]);
  const [query, setQuery] = useState('');
  const [chatResponse, setChatResponse] = useState('');
  const [form, setForm] = useState({ candidateName: '', contact: '', jobId: '' });

  useEffect(() => {
    axios.get('http://localhost:5000/jobs').then((response) => setJobs(response.data));
  }, []);

  const handleChat = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/chat', { query }).then((response) => setChatResponse(response.data));
  };

  const handleApply = (e) => {
    e.preventDefault();
    axios.post('http://localhost:5000/jobs/apply', form).then(() => alert('Application Submitted!'));
  };

  return (
    <div>
      <h1>Candidate Portal</h1>
      <input placeholder="Search by location" onChange={(e) => setQuery(e.target.value)} />
      <button onClick={() => axios.get(`http://localhost:5000/jobs?location=${query}`).then((response) => setJobs(response.data))}>
        Search
      </button>

      <h2>Available Jobs</h2>
      <ul>
        {jobs.map((job) => (
          <li key={job.id}>
            {job.title} - {job.location}
            <form onSubmit={handleApply}>
              <input placeholder="Name" onChange={(e) => setForm({ ...form, candidateName: e.target.value })} />
              <input placeholder="Contact" onChange={(e) => setForm({ ...form, contact: e.target.value })} />
              <button type="submit" onClick={() => setForm({ ...form, jobId: job.id })}>
                Apply
              </button>
            </form>
          </li>
        ))}
      </ul>

      <h2>Chat with ChatGPT</h2>
      <form onSubmit={handleChat}>
        <input placeholder="Ask something..." onChange={(e) => setQuery(e.target.value)} />
        <button type="submit">Send</button>
      </form>
      <p>{chatResponse}</p>
    </div>
  );
};

export default CandidatePortal;
