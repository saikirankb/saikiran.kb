import './App.css';
import{BrowserRouter,Route,Link,Routes} from 'react-router-dom';
import CandidatePortal from './Components/CandidatePortal';
import AdminPanel from './Components/AdminPanel';


function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <nav>
        <Link to="/CandidatePortal">CandidatePortal</Link>
        <Link to="/AdminPanel">AdminPanel</Link>
      </nav>
      <Routes>
        <Route path='CandidatePortal' element={<CandidatePortal></CandidatePortal>}></Route>
        <Route path='AdminPanel' element={<AdminPanel></AdminPanel>}></Route>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
