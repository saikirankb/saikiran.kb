const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise'); // Promise-based MySQL connection
const axios = require('axios');
require('dotenv').config();
const cors = require('cors');

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MySQL Database Connection Pool
const db = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || 'password',
  database: process.env.DB_NAME || 'job_portal',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Routes
// Admin: Add a new job
app.post('/admin/job', async (req, res) => {
  const { title, description, location, salary, email } = req.body;

  if (!title || !description || !location || !salary || !email) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const query = `INSERT INTO jobs (title, description, location, salary, email) VALUES (?, ?, ?, ?, ?)`;
    await db.execute(query, [title, description, location, salary, email]);
    res.status(201).json({ message: 'Job added successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add job', details: err.message });
  }
});

// Admin: List all jobs
app.get('/admin/jobs', async (req, res) => {
  try {
    const [results] = await db.query('SELECT * FROM jobs');
    res.status(200).json(results);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch jobs', details: err.message });
  }
});

// Candidate: Fetch available jobs with optional location filter
app.get('/jobs', async (req, res) => {
  const { location } = req.query;
  try {
    const query = location
      ? `SELECT * FROM jobs WHERE location LIKE ?`
      : `SELECT * FROM jobs`;
    const params = location ? [`%${location}%`] : [];
    const [results] = await db.execute(query, params);
    res.status(200).json(results);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch jobs', details: err.message });
  }
});

// Candidate: Apply for a job
app.post('/jobs/apply', async (req, res) => {
  const { candidateName, contact, jobId } = req.body;

  if (!candidateName || !contact || !jobId) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const query = `INSERT INTO applications (candidate_name, contact, job_id) VALUES (?, ?, ?)`;
    await db.execute(query, [candidateName, contact, jobId]);
    res.status(201).json({ message: 'Application submitted successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to submit application', details: err.message });
  }
});

// ChatGPT Integration
app.post('/chat', async (req, res) => {
  const { query } = req.body;

  if (!query) {
    return res.status(400).json({ error: 'Query is required' });
  }

  try {
    const response = await axios.post(
      'https://api.openai.com/v1/chat/completions',
      {
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: query }],
      },
      { headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` } }
    );

    res.status(200).json({ reply: response.data.choices[0].message.content });
  } catch (err) {
    const errorDetails = err.response?.data || err.message;
    res.status(500).json({ error: 'Failed to process query', details: errorDetails });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
